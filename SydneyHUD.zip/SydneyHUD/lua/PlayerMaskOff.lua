if SydneyHUD:GetOption("anti_bobble") then
    function PlayerMaskOff:_get_walk_headbob()
	    return 0
    end
end
